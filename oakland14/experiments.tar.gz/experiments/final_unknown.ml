open Printf
open ExtList
open ExtArray
open ExtHashtbl
open Scenario

let () = Printexc.record_backtrace true;;
(*let () = Parmap.set_default_ncores 8;;*)

module MM = Scenario.MM;;
module ML = Scenario.ML;;

let tmax = ref 12;;

let num_locs = ref 8;;
let adapt_low = ref false;;
let adapt_wait = ref false;;
let min_cf = ref 2;;
let max_cf = ref 4;;
let attack_change = ref false;;

module PBASE = struct
  type secret = int * int
  type low = unit
  type obs = bool
  type action = secret
end;;

module P = struct
  include Scenario.MAKE_PARAMS (PBASE)

  let all_secrets = ref [];;
  let all_obss = ref [true; false];;
  let all_lows = ref [()];;
  let all_actions = ref [];;

  let all_changes = ref [||];;

  let epoch_low t ll = ll
  let epoch_obs t ll = ll
  let epoch_high t ll = ll
  let epoch_obs_prev t ll = ll

  let fix_params () =
    let all_cfs = [2;3;4] in
    all_secrets := Util.lists_prod all_cfs (Util.list_range 0 (!num_locs-1));
    all_actions := !all_secrets;

    (*let all_cfs = Util.list_range !min_cf !max_cf in*)
    
    let make_change_fun cf = begin
      fun t secrets lows obss ->
        match secrets with
          | [] -> ML.bind_uniform 0 (!num_locs - 1) (fun s -> ML.return (cf, s))
          | (cf, current_secret) :: _ ->
            if (t mod cf) = 0
            then ML.bind_uniform 0 (!num_locs - 1) (fun s -> ML.return (cf, s))
            else ML.return (cf, current_secret)
    end in

    all_changes :=
      Array.map make_change_fun (Array.of_list all_cfs)
          
  let secretgenfun () =
    ML.bind_uniform 0 ((Array.length !all_changes) - 1) ML.return

  let obsfun t secrets lows obss =
    match secrets with
      | (cf, current_secret) :: _ ->
        ML.return (current_secret = (t mod !num_locs))
      | _ -> failwith "obsfun: unexpected"

  let stratfun t lows obss =
    if !adapt_low then 
      ML.bind_uniform_in !all_lows ML.return
    else
      ML.return ()

  let float_of_bool b = if b then 1.0 else 0.0
  let bind_flip_float p k =
    ML.bind_flip p (fun v -> k (float_of_bool v))

  let attackfun t tmax secrets lows obss action =
    if (not !adapt_wait) && (not (t = tmax)) then ML.return neg_infinity else
      match (secrets, action) with
        | ((current_cf, current_secret) :: _, (action_cf, action_secret)) ->
          if !attack_change
          then ML.return (float_of_bool (current_cf = action_cf))
          else ML.return (float_of_bool (current_secret = action_secret))
        | _ -> failwith "attackfun: unexpected"

end;;

module S = Scenario.SCENARIO (P);;

let () =
  Arg.parse [
    ("--debug",
     Arg.Set Util.debug, "asdf");
    ("--adapt-low",
     Arg.Set adapt_low, "asdf");
    ("--adapt-wait",
     Arg.Set adapt_wait, "asdf");
    ("--min-cf",
     Arg.Set_int min_cf, "asdf");
    ("--max-cf",
     Arg.Set_int max_cf, "asdf");
    ("--tmax",
     Arg.Set_int tmax, "asdf");
    ("--attack-change",
     Arg.Set attack_change, "asdf");
    ("--numlocs",
     Arg.Set_int num_locs, "asdf")
  ]
    (fun s -> ()) "";

  P.fix_params ();

  S.solve !tmax (fun x -> x)
  
