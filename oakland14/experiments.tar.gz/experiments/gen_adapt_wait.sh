(./final_adapt_wait --nlocs 8 --tmax 12 --attack-odds 1.0 --obs-odds 1.00 --change-freq 4 > ../data/data_adapt_wait_a.tsv; echo "3a done") &
(./final_adapt_wait --nlocs 8 --tmax 12 --attack-odds 1.0 --obs-odds 1.00 --change-freq 4 --adapt-wait > ../data/data_adapt_wait_b.tsv; echo "3b done") &
wait
echo "ALL DONE"
