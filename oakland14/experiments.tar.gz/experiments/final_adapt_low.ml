open Printf
open ExtList
open ExtArray
open ExtHashtbl
open Scenario

let () = Printexc.record_backtrace true;;
(*let () = Parmap.set_default_ncores 8;;*)

module MM = Scenario.MM;;
module ML = Scenario.ML;;

let nlocs = ref 4;;
let tmax = ref 12;;
let change_freq = ref 13;;
let attack_odds = ref 1.00;;
let adapt_low = ref false;;
let adapt_wait = ref false;;
let strat = ref 0;;

module PBASE = struct
  type secret = int
  type low = int
  type obs = int
  type action = int
end;;

module P = struct
  include Scenario.MAKE_PARAMS (PBASE)

  let all_secrets = ref [];;
  let all_obss = ref [];;
  let all_lows = ref [];;
  let all_actions = ref [];;

  let all_strats = ref [||];;

  let epoch_low t ll = ll
  let epoch_obs t ll = ll
  let epoch_high t ll = ll

  let fix_params () =
    all_secrets := Util.list_range 0 (!nlocs-1);
    all_actions := !all_secrets;
    all_lows    := !all_secrets;
    all_obss    := [0;1];

    all_strats :=
      (*(Array.of_list (List.map Array.of_list (Util.gen_perms_of !all_secrets)));*)
      Array.of_list (List.map Array.of_list ((Util.gen_inserts_of (Util.list_range 0 (!nlocs-2)) (!nlocs - 1))));

    Util.logerr "nlocs = %d" !nlocs;
    Util.logerr "tmax = %d" !tmax;
    Util.logerr "change_freq = %d" !change_freq;
    Util.logerr "attack_odds = %f" !attack_odds;
    Util.logerr "adapt_low = %s" (Util.string_of_bool !adapt_low);
    Util.logerr "adapt_wait = %s" (Util.string_of_bool !adapt_wait);
    Util.logerr "there are %d strats" (Array.length !all_strats)
        
  let all_changes =
    ref [|
      fun t secrets lows obss ->
        match secrets with
          | [] ->
            ML.bind_uniform_in !all_secrets ML.return
          | current_secret :: rest_secrets ->
            ML.return current_secret
              (*if (t mod !change_freq) = 0 then begin
                ML.bind_uniform (-1) 1 (fun off ->
                ML.return ((current_secret + off + !nlocs) mod !nlocs))
                end else begin ML.return current_secret end*)
        |]
          
  let secretgenfun () =
    ML.return 0

  let _dist2d (x1,y1) (x2,y2) = (abs (x1 - x2)) + (abs (y1 - y2))
  let _dist1d (x1) (x2) = (abs (x1 - x2))

  let obsfun t secrets lows obss =
    match (secrets, lows) with
      | (current_secret :: _, current_low :: _) ->
        (*let d = _dist1d current_secret current_low in
          if d <= 1 then ML.return 1
          else ML.return 0*)
        if current_secret <= current_low then ML.return 1 else ML.return 0
        
        (*let odds = 
          (if      d <= 0 then 1.0
          else if d <= 1 then 0.6
          else 0.2) in
          ML.bind_flipint odds ML.return*)
      (*ML.bind_uniform (-1 * d) d
        (fun o ->
        ML.return ((current_low + o) mod !nlocs))*)
      (*ML.return d*)
      | _ -> failwith "obsfun: unexpected"
        
  let stratfun t lows obss =
    if !adapt_low then 
      ML.bind_uniform_in !all_lows ML.return
    else
      ML.return (!all_strats).(!strat).(t mod !nlocs)

  let attackfun t tmax secrets lows obss action =
    if (not !adapt_wait) && (not (t = tmax)) then ML.return neg_infinity else
      match secrets with
        | current_secret :: _ -> 
          if !attack_odds = 1.0
          then ML.return (Util.float_of_bool (action = current_secret))
          else begin
            if current_secret = action
            then ML.return !attack_odds
            else ML.return (1.0 -. !attack_odds)
          end
        | _ -> failwith "attackfun: unexpected"
end

module S = Scenario.SCENARIO (P);;

let () =
  Arg.parse [
    ("--adapt-low",
     Arg.Set adapt_low, "asdf");
    ("--adapt-wait",
     Arg.Set adapt_wait, "asdf");
    ("--change-freq",
     Arg.Set_int change_freq, "asdf");
    ("--tmax",
     Arg.Set_int tmax, "asdf");
    ("--attack-odds",
     Arg.Set_float attack_odds, "asdf");
    ("--strat",
     Arg.Set_int strat, "asdf");
    ("--nlocs",
     Arg.Set_int nlocs, "asdf")]
    (fun s -> ()) "";

  P.fix_params ();

  S.solve !tmax (fun x -> x)
  
