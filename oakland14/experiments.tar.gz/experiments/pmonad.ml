open ExtList
open Printf
open Option

let log2 a = (log a) /. (log 2.0)
;;

let maps_merge m1 m2 mf =
  Pmap.foldi
    (fun v2 p2 m ->
      Pmap.insert_with mf v2 p2 m)
    m2 m1
;;

let maps_flatten ml mf =
  match ml with
    | [] -> Pmap.empty
    | h :: rest -> List.fold_left (fun a m -> maps_merge a m mf) h rest

let list_of_map m =
  Pmap.foldi (fun v p a -> (p,v) :: a) m []

let map_of_list l =
  List.fold_left (fun a (p, v) -> Pmap.add v p a) Pmap.empty l

let map_size m =
  Pmap.fold (fun _ a -> a + 1) m 0

type prob = float
type 'a pr = 'a * prob
type 'a iter = unit -> 'a option

let is_one p = (abs_float (1.0 -. p)) <= 0.00000001
let is_zero p = (abs_float p) <= 0.00000001

module type PMONAD = sig
  type 'a dist

  type ('a, 'b) bind = ('a -> 'b dist) -> 'b dist

  val return: 'a -> 'a dist
  val of_list: (prob * 'a) list -> 'a dist

  val bind: 'a dist -> ('a, 'b) bind

  val bind_par2: 'a dist -> 'b dist -> ('a -> 'b -> 'c dist) -> 'c dist

  val iter: 'a dist -> ('a -> float -> unit) -> unit

  val bind_uniform: int -> int -> (int, 'b) bind
  val bind_uniform_in: 'a list -> ('a, 'b) bind
  val bind_flip: prob -> (bool, 'b) bind

  val condition_and_project:
    dist: ('a dist) ->
    what: ('a -> 'c) ->
    on: ('a -> 'b) ->
    ('b, 'c dist) Pmap.t

  val condition_concrete:
    dist: ('a dist) ->
    on: ('a -> bool) ->
    'a dist

  val scale: prob -> 'a dist -> 'a dist
  val length: 'a dist -> int
  val cond_vul: 'a dist -> ('a -> 'b) -> ('a -> 'c) -> prob

  val min_vul: 'a dist -> prob

  val expect: 'a dist -> ('a -> float) -> float

  val normalize: 'a dist -> 'a dist
  val scale: float -> 'a dist -> 'a dist

  val to_string: 'a dist -> string

  val project_bins: 'a dist -> ('a -> 'b) -> ('a -> 'c) ->
    ('b, prob * ('c dist)) Pmap.t

  val prob_of: 'a dist -> 'a -> float
end;;

module MM = struct
  type 'a dist = ('a, prob) Pmap.t

  type ('a, 'b) bind = ('a -> 'b dist) -> 'b dist

  let scale p d = Pmap.map (fun p2 -> p *. p2) d;;

  let length d = map_size d

  let of_list (choices: (prob * 'a) list): 'a dist =
    List.fold_left
      (fun a (p, v) -> Pmap.insert_with (+.) v p a)
      Pmap.empty choices
  ;;

  let bind d k =
    Pmap.foldi (fun v p a ->
      maps_merge a (scale p (k v)) (+.))
      d Pmap.empty
  ;;

  let bind_par2 d1 d2 k =
    let a = ref Pmap.empty in
    Pmap.iter (fun v1 p1 ->
      Pmap.iter (fun v2 p2 -> a := maps_merge !a (scale (p1 *. p2) (k v1 v2)) (+.)) d2) d1;
    !a
  ;;

  let iter d f = Pmap.iter f d

  let bind_flip prob k =
    if is_one prob then bind (of_list [(1.0, true)]) k
    else if is_zero prob then bind (of_list [(1.0, false)]) k
    else
      bind (of_list [(prob, true);
                     (1.0 -. prob, false)]) k
  ;;

  let bind_flipint prob k =
    if is_one prob then bind (of_list [(1.0, 1)]) k
    else if is_zero prob then bind (of_list [(1.0, 0)]) k
    else
      bind (of_list [(prob, 1);
                     (1.0 -. prob, 0)]) k
  ;;

  let bind_uniform_in c k =
    let p = 1.0 /. (float_of_int (List.length c)) in
    bind (of_list (List.map (fun v -> (p, v)) c)) k
  ;;

  let bind_uniform = 
    let rec uniform_list a b = begin
      if a == b then [a]
      else a :: (uniform_list (a+1) b) 
    end in
    fun a b k ->
      let p = 1.0 /. (float_of_int (b - a + 1)) in
      bind (of_list (List.map (fun v -> (p, v)) (uniform_list a b))) k
  ;;

  let reify t = t ();;

  let fail k = Pmap.empty;;

  let to_string d =
    String.concat "\n" (List.map (fun (p, v) -> sprintf "%f: %s" p (Std.dump v)) (list_of_map d))

  let mass d = Pmap.foldi (fun _ p a -> a +. p) d 0.0;;

  let normalize d = scale (1.0 /. (mass d)) d;;

  let return v = Pmap.add v 1.0 (Pmap.empty);;

  let dist_map f d = Pmap.map f d;;

  let min_vul d = 
    Pmap.foldi
      (fun _ p best ->
        if p > best then p else best)
      d 0.0
  ;;

  let min_ent d =
    -1.0 *. (log2 (min_vul d))

  let expect d f =
    Pmap.foldi
      (fun x p acc -> acc +. p *. (f x)) d 0.0

  let project d f = dist_map f d;;

  let project_bins d fbinkey finsidebin = 
    let m = ref Pmap.empty in

    Pmap.iter (fun v p ->
      let k = fbinkey v in
      let bink = finsidebin v in

      m := Pmap.insert_with
        (fun a b -> match (a, b) with
          | ((prob_total1, `Single (bink1, p1)),
             (prob_total2, `Single (bink2, p2))) ->
            let m = Pmap.empty in
            let m = Pmap.add bink1 p1 m in
            (prob_total1 +. prob_total2, `Map (Pmap.insert_with (+.) bink2 p2 m))
          | ((prob_total1, `Map binm1), (prob_total2, `Single (bink2, p2)))
          | ((prob_total2, `Single (bink2, p2)), (prob_total1, `Map binm1)) ->
            (prob_total1 +. prob_total2,
             `Map (Pmap.insert_with (+.) bink2 p2 binm1))
          | _ -> failwith "shouldn't happen"
        )
        k
        (p, `Single (bink, p))
        !m)
      d;

    Pmap.mapi (fun k v -> match v with
      | (ptotal, `Single (k2, p)) -> (ptotal, Pmap.add k2 p (Pmap.empty))
      | (ptotal, `Map m) -> (ptotal, m)) !m

  let condition_and_project ~dist: adist ~what: whatfun ~on: onfun =
    let temp = project_bins adist onfun whatfun in
    Pmap.mapi (fun k (ptotal, m) -> scale (1.0 /. ptotal) m) temp

  let condition_concrete ~dist: adist ~on: onfun =
    let (new_dist, prob_total) = Pmap.foldi
      (fun v p (new_dist, prob_total) ->
        if onfun v
        then (Pmap.add v p new_dist, prob_total +. p)
        else (new_dist, prob_total))
      adist
      (Pmap.empty, 0.0) in
    scale (1.0 /. prob_total) new_dist

  let prob_of d e = 
    try Pmap.find e d with Not_found -> 0.0
  ;;
  
  let cond_vul d of_what given_what =
    let bins = project_bins d given_what of_what in
  let ret = ref 0.0 in 
  Pmap.iter (fun k (prob_total, m) ->
    ret := !ret +. (min_vul m)
  ) bins;
  !ret

  let to_list d = Pmap.foldi (fun v p a -> (v, p) :: a) d []
  let to_map d = d
end;;

module ML = struct
  type 'a dist = (prob * 'a) list

  type ('a, 'b) bind = ('a -> 'b dist) -> 'b dist

  let scale p d = List.map (fun (p2, v) -> (p *. p2, v)) d

  let length d = List.length d

  let rec of_list (choices: (prob * 'a) list) : 'a dist =
    choices

  let bind d k =
    List.fold_left (fun a (p, v) ->
      List.append a (scale p (k v)))
      [] d
  ;;

  let bind_par2 d1 d2 k =
    let a = ref [] in
    List.iter (fun (p1, v1) ->
      List.iter (fun (p2, v2) -> a := List.append !a (scale (p1 *. p2) (k v1 v2))) d2) d1;
    !a
  ;;

  let iter d f = List.iter (fun (p, v) -> f v p) d

  let bind_flip prob k =
    if is_one prob then k true
    else if is_zero prob then k false
    else
      bind [(prob, true);
            (1.0 -. prob, false)] k
  ;;

  let bind_flipint prob k =
    if is_one prob then k 1
    else if is_zero prob then k 0
    else
      bind [(prob, 1);
            (1.0 -. prob, 0)] k
  ;;

  let bind_uniform_in c k =
    let p = 1.0 /. (float_of_int (List.length c)) in
    bind (of_list (List.map (fun v -> (p, v)) c)) k
  ;;

  let bind_uniform = 
    let rec uniform_list a b = begin
      if a == b then [a]
      else a :: (uniform_list (a+1) b) 
    end in
    fun a b k ->
      let p = 1.0 /. (float_of_int (b - a + 1)) in
      bind (of_list (List.map (fun v -> (p, v)) (uniform_list a b))) k
  ;;

  let mass d = List.fold_left (fun a (_, p) -> a +. p) 0.0 d;;

  let return v = [(v, 1.0)];;

  let to_list l = l

  let rec to_map (l : 'a dist) : 'a MM.dist =
    List.fold_left (fun a (p, v) ->
      Pmap.insert_with (+.) v p a)
      Pmap.empty l
  ;;
end

module ME = struct
  type 'a dist = (prob * 'a) Enum.t

  type ('a, 'b) bind = ('a -> 'b dist) -> 'b dist

  let to_list d = ML.of_list (List.of_enum d)
  let to_map d = ML.to_map (to_list d)

  let of_list (choices: (prob * 'a) list) : 'a dist =
    List.enum choices

  let of_map d = of_list (MM.to_list d)

  let length d = 0

  let bind (enum1: 'a dist) (k: 'a -> 'b dist) : 'b dist =
    let maybe_e1 = ref None in
    let maybe_enum2 = ref None in

    let rec next = fun () ->
      match !maybe_e1 with
        | None ->
          maybe_e1 := Enum.get enum1;
          maybe_enum2 := None;
          begin match !maybe_e1 with
            | None -> raise Enum.No_more_elements
            | Some _ -> next () end
        | Some (p1, v1) ->
          match !maybe_enum2 with
            | None ->
              maybe_enum2 := Some (k v1);
              next ()
            | Some enum2 -> 
              match Enum.get enum2 with
                | None ->
                  maybe_e1 := None;
                  maybe_enum2 := None;
                  next ()
                | Some (p2, v2) -> (p1 *. p2, v2) in
    Enum.from next

  let bind_flip prob k =
    if is_one prob then bind (of_list [(1.0, true)]) k
    else if is_zero prob then bind (of_list [(1.0, false)]) k
    else
      bind (of_list [(prob, true);
                     (1.0 -. prob, false)]) k
  ;;

  let bind_flipint prob k =
    if is_one prob then bind (of_list [(1.0, 1)]) k
    else if is_zero prob then bind (of_list [(1.0, 0)]) k
    else
      bind (of_list [(prob, 1);
                     (1.0 -. prob, 0)]) k
  ;;

  let bind_uniform_in c k =
    let p = 1.0 /. (float_of_int (List.length c)) in
    bind (of_list (List.map (fun v -> (p, v)) c)) k
  ;;

  let bind_uniform : int -> int -> (int -> 'a dist) -> 'a dist = 
    let rec uniform_list a b = begin
      if a == b then [a]
      else a :: (uniform_list (a+1) b) 
    end in
    fun a b k ->
      let p = 1.0 /. (float_of_int (b - a + 1)) in
      bind (of_list (List.map (fun v -> (p, v)) (uniform_list a b))) k
  ;;

  let return v =
    let once = ref true in
    Enum.from (fun () -> if !once then begin once := false; (1.0, v) end else raise Enum.No_more_elements)
end;;

(*
class type ['a] prob_some = object
  method length: int
  method bind_surject: ('a -> 'b prob_some) -> 'b prob_some
  method bind_inject: ('a -> 'b prob_some) -> 'b prob_some

  method unbind_map: ('a -> 'b prob_some) -> ('a -> 'b MM.dist)
  method unbind_enum: ('a -> 'b prob_some) -> ('a -> 'b ME.dist)

  method to_map: 'a prob_mapped
  method to_enum: 'a prob_enumed
*)

(*class type ['a] type_mapped = object
  method bind_surject: ('a -> 'b type_some) -> 'b type_some

  method get_map: 'a MM.dist
  method get_enum: 'a ME.dist

end and ['a] type_enumed = object
  method bind_surject: ('a -> 'b type_some) -> 'b type_some

  method get_map: 'a MM.dist
  method get_enum: 'a ME.dist

end and *)

(*
class type ['a] prob_some = object
  method bind_surject: ('a -> 'b prob_some) -> 'b prob_some
  method bind_inject: ('a -> 'b prob_some) -> 'b prob_some

  method get_map: 'a MM.dist
  method get_enum: 'a ME.dist

  method length: int
end

type ('a,'b) binding = 'a -> 'b prob_some

class ['a] prob_mapped (i: 'a MM.dist) = object (self)
  val d = i

  method get_map = d
  method get_enum = ME.of_map d

  method length = MM.length d

  (*method scale p =
    new prob_mapped (Pmap.map (fun p2 -> p *. p2) d)*)

  (*method return v = new prob_enumed (ME.return v)*)

  method bind_surject (k: ('a,'b) binding) =
    new prob_mapped
      begin Pmap.foldi (fun v p a ->
        maps_merge a (MM.scale p (k v)#get_map) (+.))
          d Pmap.empty
      end

  method bind_inject (k: 'a -> 'b prob_some) =
    (new prob_enumed self#get_enum)#bind_inject k

end and ['a] prob_enumed (i: 'a ME.dist) = object (self)
  val d = i

  method get_map = ME.to_map d
  method get_enum = d

  method length = ME.length d

  method bind_surject (k: ('a,'b) binding) =
    (new prob_mapped self#get_map)#bind_surject k

  method bind_inject (k: ('a,'b) binding) =
    let enum1 = d in
    let maybe_e1 = ref None in
    let maybe_enum2 = ref None in

    let rec next = fun () ->
      match !maybe_e1 with
        | None ->
          maybe_e1 := Enum.get enum1;
          maybe_enum2 := None;
          begin match !maybe_e1 with
            | None -> raise Enum.No_more_elements
            | Some _ -> next () end
        | Some (p1, v1) ->
          match !maybe_enum2 with
            | None ->
              maybe_enum2 := Some ((k v1)#get_enum);
              next ()
            | Some enum2 -> 
              match Enum.get enum2 with
                | None ->
                  maybe_e1 := None;
                  maybe_enum2 := None;
                  next ()
                | Some (p2, v2) -> (p1 *. p2, v2) in
    
    new prob_enumed (Enum.from next)
end

let return (v: 'a) : ('a prob_some) = 
  new prob_enumed (ME.return v)

let uniform_list (l: 'a list) : ('a prob_some) =
  let p = 1.0 /. (float_of_int (List.length l)) in
  let aenum = List.enum (List.map (fun v -> (p, v)) l) in
  new prob_enumed aenum

let rec _uniform_int (a: int) (b: int) : (int list) = 
  if a == b then [a]
  else a :: (_uniform_int (a+1) b)

let uniform_int (a: int) (b: int) : (int prob_some) =
  uniform_list (_uniform_int a b)

let of_list (l: (float, 'a) list) : ('a prob_some) = new prob_enumed (ME.of_list l)

let flip prob =
  if prob <= 0.000001 then
    of_list [(1.0, false)]
  else if prob >= 0.99999 then
    of_list [(1.0, true)]
  else
    of_list [(prob, true); (1.0 -. prob, false)]




  
  
(*

module M = struct
  type 'a dist =
    | Mapped of 'a MM.dist
    | Enumed of 'a ME.dist
(*    | Listed of 'a ML.dist*)

  type ('a, 'b) bind = ('a -> 'b dist) -> 'b dist

  (*
    let scale p d = match d with
    | Mapped d -> Mapped (MM.scale p d)
    | Enumed d -> Enumed (ME.scale p d)
    | Listed d -> Listed (ML.scale p d)
  *)

  let length d = match d with
    | Mapped d -> MM.length d
    | Enumed d -> ME.length d
(*    | Listed d -> ML.length d*)

  let bind_surject d k = match d with
    | Mapped d -> Mapped (MM.bind d k)
    | Enumed d -> Mapped (MM.bind (ME.to_map d) k)
(*    | Listed d -> Mapped (MM.bind (ML.to_map d) k)*)

  let bind_biject d k = match d with
    | Mapped d -> Enumed (ME.bind (ME.of_map d) k)
    | Enumed d -> Enumed (ME.bind d k)
(*    | Listed d -> Mapped (ME.bind (ML.to_enum d) k)*)

(*
  let bind d k = match d with
  | Mapped d -> Mapped (MM.bind d k)
  | Enumed d -> Enumed (ME.bind d k)
  | Listed d -> Listed (ML.bind d k)
*)

(*
  let iter d f = match d with
    | Mapped d -> MM.iter d f
    | Enumed d -> ME.iter d f
    | Listed d -> ML.iter d f

  let mass d = match d with
    | Mapped d -> MM.mass d
    | Enumed d -> ME.mass d
    | Listed d -> ML.mass d
*)

  let return v = Enumed (ME.return v)

  let to_enum d = match d with
    | Mapped d -> Enumed (ME.of_map d)
    | Enumed d -> Enumed d
(*    | Listed d -> Listed (ML.to_enum d)*)

      (*
  let to_list d = match d with
    | Mapped d -> Listed (MM.to_list d)
    | Enumed d -> Listed (ME.to_list d)
    | Listed d -> Listed d
      *)

  let to_map d = match d with
    | Mapped d -> Mapped d
    | Enumed d -> Mapped (ME.to_map d)
(*    | Listed d -> Mapped (ML.to_map d)*)
end;;
*)
*)
