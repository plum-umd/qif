open Printf
open ExtList
open ExtArray
open ExtHashtbl
open Scenario

let () = Printexc.record_backtrace true;;
(*let () = Parmap.set_default_ncores 8;;*)

module MM = Scenario.MM;;
module ML = Scenario.ML;;

let num_floors = ref 0;;
let num_builds = ref 2;;

let tmax = ref 12;;

let change_freq = ref 13;;

let obs_odds = ref 1.00;;
let attack_change = ref false;;
let adapt_low = ref false;;
let adapt_wait = ref false;;

module PBASE = struct
  type secret = int * int
  type low = unit
  type obs = int
  type action = secret
end;;

module P = struct
  include Scenario.MAKE_PARAMS (PBASE)

  let all_secrets = ref [];;
  let all_obss = ref [-1;0;1];;
  let all_lows = ref [()];;
  let all_actions = ref [];;
  let all_changes = ref [||];;

  let epoch_low t ll = ll
  let epoch_obs t ll = ll
  let epoch_high t ll = ll

  let fix_params () =
    num_floors := Util.factorial (!num_builds - 1);

    all_secrets := List.fold_left
      (fun a floor -> 
        a @ (List.fold_left (fun a build -> (build, floor) :: a) [] (Util.list_range 0 (!num_builds-1))))
      [] (Util.list_range 0 (!num_floors-1));

    all_actions :=
      (*if !attack_change then
      then Util.list_range 0 !num_floors
      else*)
      !all_secrets;
    (*
      all_lows := (Util.list_range 0 !nlocs);
    *)

    let perms =
      let ps = Util.gen_perms !num_builds in
      Array.of_list (List.map Array.of_list ps) in

    let make_pref_fun floor = begin
      let perm = perms.(floor) in
      let temp = Array.create !num_builds 0 in
      Array.iteri
        (fun i v -> temp.(v) <- perm.((i+1) mod !num_builds)) perm;
      
      (*Util.logerr "perm for floor %d = %s, temp = %s" floor (Std.dump perm) (Std.dump temp);*)

      fun t secrets lows obss ->
        match secrets with
          | [] -> ML.bind_uniform 0 (!num_builds - 1)
            (fun abuild -> 
              ML.return (abuild, floor))

          | (current_build, current_floor) :: _ ->
            (if not (current_floor = floor) then failwith "something bad");
            if (t mod !change_freq) = 0
            then ML.return (temp.(current_build), current_floor)
            else ML.return (current_build, current_floor)
    end in

    all_changes :=
      Array.map make_pref_fun (Array.of_list (Util.list_range 0 (!num_floors-1)))
          
  let secretgenfun () =
    ML.bind_uniform 0 (!num_floors - 1) ML.return

  let obsfun t secrets lows obss =
    match secrets with
      | ((current_build, current_floor) :: _) ->
        ML.bind_flip !obs_odds (fun b ->
          if b then ML.return current_build else ML.return (-1))
      | _ -> failwith "absfun: unexpected"

  let stratfun t lows obss =
    if !adapt_low then 
      ML.bind_uniform_in !all_lows ML.return
    else
      ML.return ()

  let float_of_bool b = if b then 1.0 else 0.0
  let bind_flip_float p k =
    ML.bind_flip p (fun v -> k (float_of_bool v))

  let attackfun t tmax secrets lows obss action =
    if (not !adapt_wait) && (not (t = tmax)) then ML.return neg_infinity else
      match (secrets, action) with
        | ((current_build, current_floor) :: _,
           (action_build, action_floor)) -> 
          if !attack_change
          then ML.return (float_of_bool (current_floor = action_floor))
          else ML.return (float_of_bool ((current_build, current_floor) = (action_build, action_floor)))
        | _ -> failwith "attackfun: unexpected"

end;;

module S = Scenario.SCENARIO (P);;

let () =
  Arg.parse [
    ("--debug",
     Arg.Set Util.debug, "asdf");
    ("--adapt-low",
     Arg.Set adapt_low, "asdf");
    ("--adapt-wait",
     Arg.Set adapt_wait, "asdf");
    ("--change-freq",
     Arg.Set_int change_freq, "asdf");
    ("--tmax",
     Arg.Set_int tmax, "asdf");
    ("--obs-odds",
     Arg.Set_float obs_odds, "asdf");
    ("--attack-change",
     Arg.Set attack_change, "asdf");
    ("--nbuilds",
     Arg.Set_int num_builds, "asdf")]
    (fun s -> ()) "";

  P.fix_params ();

  S.solve !tmax (fun x -> x)
  
