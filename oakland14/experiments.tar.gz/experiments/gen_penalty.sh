for P in 0.00 0.02 0.04 0.06 0.08 0.10 0.12
do
    (./final_penalty --nlocs 8 --tmax 12 --change-freq 4 --obs-penalty ${P} --adapt-low --adapt-wait > ../data/data_penalty/data_penalty_${P}_wait.tsv; echo "6 ${P} wait done") &
    (./final_penalty --nlocs 8 --tmax 12 --change-freq 4 --obs-penalty ${P} --adapt-low > ../data/data_penalty/data_penalty_${P}_nowait.tsv; echo "6 ${P} nowait done") &
    wait
done

wait
echo "ALL DONE"
