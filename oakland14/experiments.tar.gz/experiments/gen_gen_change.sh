(./final_gen_change --nlocs 8 --tmax 12 --attack-odds 1.0 --obs-odds 1.0 --change-freq 13 > ../data/data_gen_change_a.tsv; echo "1a done") &
(./final_gen_change --nlocs 8 --tmax 12 --attack-odds 0.8 --obs-odds 1.0 --change-freq 13 > ../data/data_gen_change_b.tsv; echo "1b done") &
(./final_gen_change --nlocs 8 --tmax 12 --attack-odds 0.8 --obs-odds 1.0 --change-freq 4 > ../data/data_gen_change_c.tsv; echo "1c done") &
wait
echo "ALL DONE"
