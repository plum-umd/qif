open Printf
open ExtList
open ExtArray
open ExtHashtbl
open Scenario

let () = Printexc.record_backtrace true;;
(*let () = Parmap.set_default_ncores 8;;*)

module MM = Scenario.MM;;
module ML = Scenario.ML;;

let nlocs = ref 8;;
let tmax = ref 12;;
let change_freq = ref 4;;
let obs_odds = ref 1.00;;
let attack_odds = ref 1.00;;
let adapt_low = ref false;;
let adapt_wait = ref false;;
let obs_penalty = ref 0.00;;

module PBASE = struct
  type secret = int
  type low = int
  type obs = int
  type action = int
end;;

module P = struct
  include Scenario.MAKE_PARAMS (PBASE)

  let all_secrets = ref [];;
  let all_obss = ref [0;1];;
  let all_lows = ref [];;
  let all_actions = ref [];;

(*  let epoch_low t ll = ll
  let epoch_obs t ll =
    if t mod !change_freq = 0
    then [List.hd ll]
    else ll 
  let epoch_obs_prev t ll =
    if t mod !change_freq = 0
    then List.take 2 ll
    else ll 
  let epoch_high t ll =
    if t mod !change_freq = 0
    then [List.hd ll]
    else ll*)

  let epoch_low t ll = ll
  let epoch_obs t ll = List.take !change_freq ll 
  let epoch_obs_prev t ll = List.take (!change_freq-1) ll 
  let epoch_high t ll = List.take !change_freq ll

  let fix_params () =
    all_secrets := Util.list_range 0 (!nlocs-1);
    all_actions := (-1) :: !all_secrets;
    all_lows := [-1; 0]
        
  let all_changes = ref
    [|
      fun t secrets lows obss ->
        match secrets with
          | [] ->
            ML.bind_uniform_in !all_secrets ML.return
          | current_secret :: rest_secrets ->
            if (t mod !change_freq) = 0
            then ML.bind_uniform_in !all_secrets ML.return
            else ML.return current_secret
    |]
          
  let secretgenfun () =
    ML.return 0

  let obsfun t secrets lows obss =
    match (secrets, lows) with
      | (current_secret :: _, current_low :: _) ->
        if current_low = -1 then ML.return 0
        else begin
          if current_secret = t mod !nlocs
          then ML.return 1
          else ML.return 0
        end
      | _ -> failwith "absfun: unexpected"
  

  let stratfun t lows obss =
    (*if !adapt_low then 
      ML.bind_uniform_in !all_lows ML.return
      else*)
    ML.bind_uniform_in [-1; 0] ML.return

  let float_of_bool b = if b then 1.0 else 0.0
  let bind_flip_float p k =
    ML.bind_flip p (fun v -> k (float_of_bool v))

  let count_obss lows = 
    List.fold_left (fun a l -> a + (if l >= 0 then 1 else 0)) 0 lows

  let attackfun t tmax secrets lows obss action =
    if (not !adapt_wait) && (not (t = tmax)) then ML.return neg_infinity else
      let obs_cost = 0.0 -. (!obs_penalty *. (float_of_int (count_obss lows))) in
      if action = -1 then 0.0 +. ML.return obs_cost
      else
        match secrets with
          | current_secret :: _ -> 
            ML.return (obs_cost +.
                         (if current_secret = action
                          then 1.0
                          else -1.0))
          | _ -> failwith "attackfun: unexpected"

end;;

module S = Scenario.SCENARIO (P);;

let () =
  Arg.parse [
    ("--debug",
     Arg.Set Util.debug, "asdf");
    ("--adapt-low",
     Arg.Set adapt_low, "asdf");
    ("--adapt-wait",
     Arg.Set adapt_wait, "asdf");
    ("--change-freq",
     Arg.Set_int change_freq, "asdf");
    ("--tmax",
     Arg.Set_int tmax, "asdf");
    ("--obs-odds",
     Arg.Set_float obs_odds, "asdf");
    ("--attack-odds",
     Arg.Set_float attack_odds, "asdf");
    ("--obs-penalty",
     Arg.Set_float obs_penalty, "asdf");
    ("--nlocs",
     Arg.Set_int nlocs, "asdf")]
    (fun s -> ()) "";

  P.fix_params ();

  S.solve_with_epochs !tmax (fun x -> x)
    (*S.solve !tmax (fun x -> x)*)
  
