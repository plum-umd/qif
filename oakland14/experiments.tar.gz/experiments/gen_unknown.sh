./final_unknown --tmax 12 > ../data/data_unknown_a.tsv &
./final_unknown --tmax 12 --adapt-wait > ../data/data_unknown_b.tsv &

./final_unknown --tmax 12 --attack-change > ../data/data_unknown_ac.tsv &
./final_unknown --tmax 12 --adapt-wait --attack-change > ../data/data_unknown_bc.tsv &

wait
echo "ALL DONE"
