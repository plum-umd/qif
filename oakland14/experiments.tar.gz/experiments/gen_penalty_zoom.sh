for P in 0.1400 0.1405 0.1410 0.1415 0.1420 0.1425 0.1430
do
    (./final_penalty --nlocs 8 --tmax 12 --change-freq 4 --obs-penalty ${P} --adapt-low --adapt-wait > ../data/data_penalty/data_penalty_${P}_wait.tsv; echo "6 ${P} wait done") &
done

wait
echo "ALL DONE"
