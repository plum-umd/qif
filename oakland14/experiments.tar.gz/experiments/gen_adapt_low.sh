(./final_adapt_low --tmax 4 --nlocs 8 --change-freq 13 --adapt-low > ../data/data_adapt_low/adaptlow.tsv; echo "low adapt done") &

SSTART=0
#SEND=8*7*6*5*4*3*2*1
SEND=8

for (( S = $SSTART; S < $SEND; S += 1 ))
do
    (./final_adapt_low --strat $((S+0)) --tmax 12 --nlocs 8 --change-freq 13 > ../data/data_adapt_low/noadapt_strat$((S+0)).tsv; echo "strat $((S+0)) noadapt done") &
    #(./final_adapt_low --strat $((S+1)) --tmax 12 --nlocs 8 --change-freq 13 > ../data/data_adapt_low/noadapt_strat$((S+1)).tsv; echo "strat $((S+1)) noadapt done") &
    #(./final_adapt_low --strat $((S+2)) --tmax 12 --nlocs 8 --change-freq 13 > ../data/data_adapt_low/noadapt_strat$((S+2)).tsv; echo "strat $((S+2)) noadapt done") &
    #(./final_adapt_low --strat $((S+3)) --tmax 12 --nlocs 8 --change-freq 13 > ../data/data_adapt_low/noadapt_strat$((S+3)).tsv; echo "strat $((S+3)) noadapt done") &
    #(./final_adapt_low --strat $((S+4)) --tmax 12 --nlocs 8 --change-freq 13 > ../data/data_adapt_low/noadapt_strat$((S+4)).tsv; echo "strat $((S+4)) noadapt done") &
    #(./final_adapt_low --strat $((S+5)) --tmax 12 --nlocs 8 --change-freq 13 > ../data/data_adapt_low/noadapt_strat$((S+5)).tsv; echo "strat $((S+5)) noadapt done") &
    #(./final_adapt_low --strat $((S+6)) --tmax 12 --nlocs 8 --change-freq 13 > ../data/data_adapt_low/noadapt_strat$((S+6)).tsv; echo "strat $((S+6)) noadapt done") &
    #(./final_adapt_low --strat $((S+7)) --tmax 12 --nlocs 8 --change-freq 13 > ../data/data_adapt_low/noadapt_strat$((S+7)).tsv; echo "strat $((S+7)) noadapt done") &
    wait
done

wait

echo "ALL DONE"

