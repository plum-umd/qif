Oakland 14 and Tech-Report Experiments

cd experiments
make all
sh gen_all.sh
cd ../data
sh makepdfs.sh

experiments/final_*.ml
experiments/gen_*.sh
experiments/gen_all.sh
data/plot_*.gnu
data/makepdfs.sh
