Quantifying Information Flow for Dynamic Secrets
Oakland 14 and Tech-Report Experiments
Piotr Mardziel <piotrm@gmail.com>

REQUIREMENTS:
  ocaml
  ocamlfind
  extlib
  gnuplot (optional)
  ps2pdf (optional)

On Mac, the easiest way of installing these is:

  1. Install homebrew.
     ruby -e "$(curl -fsSL https://raw.github.com/Homebrew/homebrew/go/install)"

  2. Install ocaml using homebrew:
     brew install ocaml

  3. Install opam using homebrew:
     brew install opam

  4. Install ocamlfind using opam:
     opam install ocamlfind

  5. Install extlib using opam:
     opam install extlib

  6. (optional) To make the figures used in the paper, you will also
       need gnuplot: 
     brew install gnuplot
  7. (optional) To make .pdf figures from .eps figures you will need
       ps2pdf.

BUILDING:

  8. You should now be reading to build and run the experiments:
     cd experiments
     make all
     sh gen_all.sh

  9. (optional) You can also make the figures used in the paper:
     cd ../data
     sh makepdfs.sh

CONTENTS:

  experiments/
    pmonad.ml pmap.ml pmap.mli util.ml - probabilistic monad
      implementation 
    common.ml scenario.ml - optimal adversary solver
    final_XXX.ml - the various experiments
      these can be built individually using "make final_XXX"
    gen_XXX.sh - scripts to generate the data for the experiments in
      the paper 
    gen_all.sh - script to run all of the previous

  data/
    data_XXX/ - outputs of experiments are put here
    plot_XXX.gnu - gnuplot files for generating figures
      these can be built using "gnuplot plot_XXX.gnu"
    fig_XXX.eps - generated figures using the above
    common.gnu - some common definitions for the figures
    makepdfs.sh - generates all figures, converts them to pdf and
      moves them to ../figures 

  figures/
    fig_XXX.pdf - figures from paper, created using makepdfs.sh above
