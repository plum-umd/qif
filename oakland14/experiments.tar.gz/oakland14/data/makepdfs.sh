#!/bin/bash

mkdir -p ../figures

for p in *.gnu ; do
  gnuplot $p
done;

for f in *.eps ; do
  ps2pdf -dEPSCrop "$f"
done;

mv *.pdf ../figures
