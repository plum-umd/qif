mkdir -p ../data/data_adapt_wait

(./final_adapt_wait --nlocs 8 --tmax 12 --change-freq 4 > ../data/data_adapt_wait/a.tsv; echo "3a done") &
(./final_adapt_wait --nlocs 8 --tmax 12 --change-freq 4 --adapt-wait > ../data/data_adapt_wait/b.tsv; echo "3b done") &
wait
echo "ALL DONE"
