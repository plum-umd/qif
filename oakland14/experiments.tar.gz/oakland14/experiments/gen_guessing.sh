mkdir -p ../data/data_guessing

(./final_guessing --nlocs 8 --tmax 12 --change-freq 4 > ../data/data_guessing/a.tsv; echo "4a done") &
(./final_guessing --nlocs 8 --tmax 12 --change-freq 4 --adapt-wait > ../data/data_guessing/b.tsv; echo "4b done") &
wait
echo "ALL DONE"
