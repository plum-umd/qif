mkdir -p ../data/data_unknown

./final_unknown --tmax 12 > ../data/data_unknown/a.tsv &
./final_unknown --tmax 12 --adapt-wait > ../data/data_unknown/b.tsv &

./final_unknown --tmax 12 --attack-change > ../data/data_unknown/ac.tsv &
./final_unknown --tmax 12 --adapt-wait --attack-change > ../data/data_unknown/bc.tsv &

wait
echo "ALL DONE"
