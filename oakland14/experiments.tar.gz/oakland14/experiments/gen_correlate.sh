mkdir -p ../data/data_correlate

for P in 1 2 3 4 5
do
    (./final_correlate --nbuilds 5 --tmax 12 --obs-odds 0.5 --change-freq ${P} > ../data/data_correlate/${P}.tsv; echo "7 ${P} done") &
done

wait
echo "HALF DONE"

for P in 1 2 3 4 5
do
    (./final_correlate --nbuilds 5 --tmax 12 --attack-change --obs-odds 0.5 --change-freq ${P} > ../data/data_correlate/${P}_change.tsv; echo "7 ${P} change done") &
done

wait
echo "ALL DONE"
