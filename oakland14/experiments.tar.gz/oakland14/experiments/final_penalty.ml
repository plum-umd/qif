open ExtList
open ExtArray

module MM = Scenario.MM;;
module ME = Scenario.ME;;
module C = Common;;

let obs_penalty = ref 0.00;;

module P = struct
  include Scenario.MAKE_FTYPES (struct
    type high = int
    type low = int
    type obs = int
    type exp = int
  end)

  let all_highs = ref [];;
  let all_obss = ref [0;1];;
  let all_lows = ref [];;
  let all_exps = ref [];;

  let epoch_low t ll = ll
  let epoch_obs t ll = List.take !C.change_freq ll 
  let epoch_obs_prev t ll = List.take (!C.change_freq-1) ll 
  let epoch_high t ll = List.take !C.change_freq ll

  let fix_params () =
    all_highs := Util.list_range 0 (!C.nlocs-1);
    all_exps := (-1) :: !all_highs;
    all_lows := [-1; 0]
        
  let all_highfs = ref
    [|
      fun t highs lows obss ->
        match highs with
          | [] ->
            ME.bind_uniform_in !all_highs ME.return
          | current_high :: rest_highs ->
            if (t mod !C.change_freq) = 0
            then ME.bind_uniform_in !all_highs ME.return
            else ME.return current_high
    |]
          
  let highgen_func () =
    ME.return 0

  let system t highs lows obss =
    match (highs, lows) with
      | (current_high :: _, current_low :: _) ->
        if current_low = -1 then ME.return 0
        else begin
          if current_high = t mod !C.nlocs
          then ME.return 1
          else ME.return 0
        end
      | _ -> failwith "absfun: unexpected"

  let strat_func t lows obss =
    ME.bind_uniform_in [-1; 0] ME.return

  let _count_obss lows = 
    List.fold_left (fun a l -> a + (if l >= 0 then 1 else 0)) 0 lows

  let gain_func t tmax highs lows obss exp =
    if (not !C.adapt_wait) && (not (t = tmax)) then ME.return neg_infinity else
      let obs_cost = 0.0 -. (!obs_penalty *. (float_of_int (_count_obss lows))) in
      if exp = -1 then ME.return obs_cost
      else
        match highs with
          | current_high :: _ -> 
            ME.return (obs_cost +.
                         (if current_high = exp
                          then 1.0
                          else -1.0))
          | _ -> failwith "attackfun: unexpected"

end;;

module S = Scenario.SCENARIO (P);;

let () =
  C.parse [("--obs-penalty",
            Arg.Set_float obs_penalty, "observation penalty")];
  P.fix_params ();
  S.solve_with_epochs !C.tmax (fun x -> x)

