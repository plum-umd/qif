mkdir -p ../data/data_memory

for ML in 0 1 2 3 4 5 6 7 8
do
    (./final_memory --mem-limit ${ML} --nlocs 8 --tmax 16 --change-freq 8 --adapt-wait > ../data/data_memory/${ML}_wait.tsv; echo "5 ${ML} wait done") &
    (./final_memory --mem-limit ${ML} --nlocs 8 --tmax 16 --change-freq 8  > ../data/data_memory/${ML}_nowait.tsv; echo "5 ${ML} nowait done") &
done

wait
echo "ALL DONE"
