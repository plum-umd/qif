module MM = Scenario.MM;;
module ME = Scenario.ME;;
module C = Common;;

let attack_odds = ref 1.00;;

module P = struct
  include Scenario.MAKE_FTYPES (struct
    type high = int
    type low = int
    type obs = bool
    type exp = int
  end)

  let all_highs = ref [];;
  let all_obss = ref ([true; false]);;
  let all_lows = ref [];;
  let all_exps = ref [];;

  let epoch_low t ll = ll
  let epoch_obs t ll = ll
  let epoch_obs_prev t ll = ll
  let epoch_high t ll = ll

  let fix_params () =
    all_highs := Util.list_range 0 (!C.nlocs-1);
    all_exps := !all_highs;
    all_lows := !all_highs

  let all_highfs
      = ref [|
        fun t highs lows obss ->
          match highs with
            | [] ->
              ME.bind_uniform_in !all_highs ME.return
            | current_high :: rest_highs ->
              if t mod !C.change_freq = 0
              then ME.bind_uniform_in !all_highs ME.return
              else ME.return current_high
            |]
          
  let highgen_func () = ME.return 0

  let strat_func t lows obss = ME.return (t mod !C.nlocs)

  let system t highs lows obss =
    match (highs, lows) with
      | (current_high :: _, current_low :: _) ->
        ME.return (current_high = current_low)
      | _ -> failwith "absfun: unexpected"
  
  let gain_func t tmax highs lows obss exp =
    if (not !C.adapt_wait) && (not (t = tmax)) then ME.return neg_infinity else
      match highs with
        | current_high :: _ -> 
          if !attack_odds = 1.0
          then ME.return (Util.float_of_bool (exp = current_high))
          else begin
            if current_high = exp
            then ME.return !attack_odds
            else ME.return (1.0 -. !attack_odds)
          end
        | _ -> failwith "attackfun: unexpected"
end

module S = Scenario.SCENARIO (P);;

let () =
  C.parse [("--attack-odds",
            Arg.Set_float attack_odds, "attack probability")];
  P.fix_params ();
  S.solve !C.tmax (fun x -> x)
