open Printf
open ExtList
open ExtArray
open ExtHashtbl

let () = Printexc.record_backtrace true;;

module MM = Pmonad.MM;;
module ME = Pmonad.ME;;

module type BASE_TYPES = sig
  type high
  type low
  type obs
  type exp
end;;

module type PARAMS = sig
  include BASE_TYPES

  type highf = int ->
      high list -> low list -> obs list -> high ME.dist
  type highgenf = unit ->
      int ME.dist
  type sysf = int ->
      high list -> low list -> obs list -> obs ME.dist
  type gainf = int -> int ->
      high list -> low list -> obs list -> exp -> float ME.dist
  type actf = int ->
      low list -> obs list -> low ME.dist

  val epoch_high: int -> high list -> high list
  val epoch_low: int -> low list -> low list
  val epoch_obs: int -> obs list -> obs list
  val epoch_obs_prev: int -> obs list -> obs list

  val all_highs: high list ref
  val all_lows: low list ref
  val all_obss: obs list ref
  val all_exps: exp list ref
  val all_highfs: highf array ref

  val highgen_func: highgenf
  val strat_func: actf
  val system: sysf
  val gain_func: gainf
end;;

module MAKE_FTYPES (BT: BASE_TYPES) = struct
  include BT

  type highf = int ->
      BT.high list -> BT.low list -> BT.obs list -> BT.high ME.dist
  type highgenf = unit ->
      int ME.dist
  type sysf = int ->
      BT.high list -> BT.low list -> BT.obs list -> BT.obs ME.dist
  type gainf = int -> int ->
      BT.high list -> BT.low list -> BT.obs list -> BT.exp -> float ME.dist
  type actf = int ->
      BT.low list -> BT.obs list -> BT.low ME.dist
end;;

module SCENARIO (P: PARAMS) = struct
  include P

  type history = {highs: high list;
                  lows: low list;
                  obss: obs list}

  let scenario (tmax: int) : history ME.dist =
    Util.logerr "generating scenario up to time %d" tmax;

    let ahighgenf = P.highgen_func in
    let asysf = P.system in
    let aactf = P.strat_func in
    
    let rec step t achangefun history = 
      if t >= tmax then ME.return history
      else begin
        ME.bind
          (!all_highfs.(achangefun) (t+1) history.highs history.lows history.obss)
          (fun new_high ->
            ME.bind
              (aactf t history.lows history.obss)
              (fun new_low ->
                let history = {history with
                  highs = new_high :: history.highs;
                  lows = new_low :: history.lows} in
                ME.bind (asysf t (List.tl history.highs) history.lows history.obss)
                  (fun new_obs ->
                    let history = {history with obss = new_obs :: history.obss} in
                    step (t+1) achangefun history)))
      end in

    ME.bind (ahighgenf ())
      (fun achangefun ->
        ME.bind (!all_highfs.(achangefun) 0 [] [] [])
          (fun inithigh ->
            let history = {highs = [inithigh];
                           lows = [];
                           obss = []} in
            (step 0 achangefun history)))

  let solve tmax mf =
    let d = scenario tmax in
    (*    Util.logerr "joint dist made (size %d)" (ME.length d);*)
    let (dist: history MM.dist) = ME.to_map d in

    Util.logerr "joint dist map has size %d" (MM.length dist);

    (*Util.logdebug "\n%s" (MM.to_string dist);*)
    
    let conds = Array.of_list
      begin List.map (fun t ->
        Util.logerr "t = %d" t;
        
        let dist = MM.bind dist
          (fun history -> MM.return
            {highs = List.drop (tmax - t) history.highs;
             lows = List.drop (tmax - t) history.lows;
             obss = List.drop (tmax - t) history.obss}) in
        
        (*Util.logdebug "dist = %s" (MM.to_string dist);*)
        
        let ret2 = MM.condition_and_project ~dist: dist
          ~on: (fun history -> (history.lows,
                                history.obss))
          ~what: (fun history -> history.highs) in
        
        if t > 0 then 
          let ret1 = MM.condition_and_project ~dist: dist
            ~on: (fun history -> (history.lows,
                                  List.tl history.obss))
            ~what: (fun history -> (List.hd history.obss)) in
          (Some ret1, ret2)
        else
          (None, ret2)

      ) (Util.list_range 0 tmax) end in
    
    Util.logerr "bins made";
    
    for tmax = 0 to tmax do
      Util.logerr "generating optimal choice matrix for tmax = %d" tmax;

      let a = Array.make (tmax + 1) (Hashtbl.create 1) in
      
      for t = tmax downto 0 do
        Util.logdebug "t = %d" t;

        let (_, binmap) = conds.(t) in
        
        let ca = Hashtbl.create (Pmap.approx_size binmap) in
        a.(t) <- ca;
        
        Pmap.iter (fun (lows, obss) m ->  
          (*Util.logdebug "lows = %s" (Std.dump lows);
            Util.logdebug "obss = %s" (Std.dump obss);
            Util.logdebug "m =\n%s" (MM.to_string m);*)

          let attack_now = Util.maximize_float
            (List.map (fun exp ->
              (*Util.logdebug "considering exp = %s" (Std.dump exp);*)
              let temp = MM.expect
                (MM.bind m
                   (fun highs -> 
                     MM.bind (ME.to_map (gain_func t tmax highs lows obss exp)) MM.return))
                (fun x -> x) in
              (*Util.logdebug "prob of win = %f" temp;*)
                temp)
               !all_exps) in
          
          let attack_later = begin
            let best_later = ref neg_infinity in
              
            if t < tmax then begin
              List.iter (fun l ->
                (*Util.logdebug "considering low = %s" (Std.dump l);*)

                let na = a.(t+1) in
                let (Some next_cond, _) = conds.(t+1) in

                let goodness = 
                  try 
                    let next_dist = Pmap.find (l :: lows, obss) next_cond in
                    (*Util.logdebug "next dist =\n%s" (MM.to_string next_dist);*)
                    MM.expect next_dist (fun o -> 
                      Hashtbl.find na (l :: lows, o :: obss)
                    )

                  with | Not_found -> neg_infinity in
                
                if goodness > !best_later then best_later := goodness) !all_lows
            end;
              
            !best_later
          end in

          (*Util.logdebug "attack_now = %f, attack_later = %f" attack_now attack_later;*)
          (*Util.logdebug "";*)
          
          Hashtbl.replace ca (lows, obss) (max attack_now attack_later)
        ) binmap
      done;
      printf "%d\t%f\n%!" tmax (mf (Hashtbl.find a.(0) ([], [])))
    done

  let solve_mem_limit tmax memlimit mf =
    let d = scenario tmax in

    (*Util.logerr "joint dist made (size %d)" (ME.length d);*)
    let dist = ME.to_map d in
    Util.logerr "joint dist map has size %d" (MM.length dist);
    (*Util.logerr "\n%s" (MM.to_string dist);*)
    
    let conds = Array.of_list
      begin List.map (fun t ->
        Util.logerr "t = %d" t;
        
        let dist = MM.bind dist
          (fun history -> MM.return
            {highs = List.drop (tmax - t) history.highs;
             lows = List.drop (tmax - t) history.lows;
             obss = List.drop (tmax - t) history.obss}) in
        
        (*Util.logerr "dist =\n%s" (MM.to_string dist);*)
        
        let ret2 = MM.condition_and_project ~dist: dist
          ~on: (fun history -> (List.take memlimit history.lows, List.take memlimit history.obss))
          ~what: (fun history -> (history.highs)) in
        
        if t > 0 then 
          let ret1 = MM.condition_and_project ~dist: dist
            ~on: (fun history -> (List.take memlimit history.lows, List.take memlimit (List.tl history.obss)))
            ~what: (fun history -> (List.hd history.obss)) in
          (Some ret1, ret2)
        else
          (None, ret2)

      ) (Util.list_range 0 tmax) end in
    
    Util.logerr "bins made";
    
    for tmax = 0 to tmax do
      Util.logerr "generating optimal choice matrix for tmax = %d" tmax;

      let a = Array.make (tmax + 1) (Hashtbl.create 1) in
      
      for t = tmax downto 0 do
        (*Util.logerr "t = %d" t;*)

        let (_, binmap) = conds.(t) in
        
        let ca = Hashtbl.create (Pmap.approx_size binmap) in
        a.(t) <- ca;
        
        (*Util.logerr "ca = %s" (Std.dump ca);*)
        
        Pmap.iter (fun (lows, obss) m ->  
          (*Util.logerr "lows = %s" (Std.dump lows);
            Util.logerr "obss = %s" (Std.dump obss);
            Util.logerr "m =\n%s" (MM.to_string m);*)

          let attack_now = Util.maximize_float
            (List.map (fun exp ->
              (*Util.logerr "considering exp = %s" (Std.dump exp);*)
              let temp = MM.expect
                (MM.bind m
                   (fun highs -> 
                     MM.bind (ME.to_map (gain_func t tmax highs lows obss exp)) MM.return))
                (fun x -> x) in
              (*Util.logerr "prob of win = %f" temp; *) temp)
               !all_exps) in
          
          let attack_later = begin
            let best_later = ref neg_infinity in
              
            if t < tmax then begin
              List.iter (fun l ->
                let na = a.(t+1) in
                let (Some next_cond, _) = conds.(t+1) in

                let goodness = 
                  try
                    let next_dist = Pmap.find
                      (List.take memlimit (l :: lows),
                       obss) next_cond in
                    (*Util.logerr "next dist =\n%s" (MM.to_string next_dist);*)
                    MM.expect next_dist (fun o ->
                      Hashtbl.find
                        na (t+1,
                            List.take memlimit (l :: lows),
                            List.take memlimit (o :: obss)))
                      
                  with | Not_found -> neg_infinity in
                
                if goodness > !best_later then best_later := goodness) !all_lows
            end;
              
            !best_later
          end in

          (*Util.logerr "attack_now = %f, attack_later = %f" attack_now attack_later;
            Util.logerr "";*)
          
          let visible = (t,
                         List.take memlimit lows,
                         List.take memlimit obss) in

          Hashtbl.replace ca visible (max attack_now attack_later)

        ) binmap
      done;
      printf "%d\t%f\n%!" tmax (mf (Hashtbl.find a.(0) (0, [], [])))
    done

  let scenario_with_epochs (tmax: int) : history MM.dist =
    Util.logerr "generating scenario up to time %d" tmax;

    let ahighgenfun = P.highgen_func in
    let aobsfun = P.system in
    let astratfun = P.strat_func in
    
    let rec step t achangefun dhistory = 
      if t >= tmax then dhistory
      else
        let dhistory = 
          MM.bind dhistory
            (fun history ->
              MM.bind
                (ME.to_map ((!all_highfs.(achangefun) (t+1) history.highs history.lows history.obss)))
                (fun new_high ->
                  MM.bind
                    (ME.to_map (astratfun t history.lows history.obss))
                    (fun new_low ->
                      MM.bind (ME.to_map (aobsfun t history.highs (new_low :: history.lows) history.obss))
                        (fun new_obs ->
                          MM.return
                            {obss = P.epoch_obs (t+1) (new_obs :: history.obss);
                             highs = P.epoch_high (t+1) (new_high :: history.highs);
                             lows = P.epoch_low (t+1) (new_low :: history.lows)})))) in

        step (t+1) achangefun dhistory in

    MM.bind (ME.to_map (ahighgenfun ()))
      (fun achangefun ->
        MM.bind (ME.to_map (!all_highfs.(achangefun) 0 [] [] []))
          (fun inithigh ->
            let dhistory = MM.return {highs = [inithigh];
                                      lows = [];
                                      obss = []} in
            (step 0 achangefun dhistory)))

  let solve_with_epochs tmax mf =
    let conds = Array.of_list
      begin List.map (fun t ->
        let dist = scenario_with_epochs t in
        (*let (dist: history MM.dist) = ME.to_map d in*)

        Util.logerr "joint dist map has size %d" (MM.length dist);
        (*Util.logdebug "\n%s" (MM.to_string dist);*)
        Util.logerr "t = %d" t;
        
        let ret2 = MM.condition_and_project ~dist: dist
          ~on: (fun history -> (history.lows,
                                history.obss))
          ~what: (fun history -> history.highs) in
        
        if t > 0 then 
          let ret1 = MM.condition_and_project ~dist: dist
            ~on: (fun history -> (history.lows,
                                  List.tl history.obss))
            ~what: (fun history -> (List.hd history.obss)) in
          (Some ret1, ret2)
        else
          (None, ret2)

      ) (Util.list_range 0 tmax) end in
    
    Util.logerr "bins made";
    
    for tmax = 0 to tmax do
      Util.logerr "generating optimal choice matrix for tmax = %d" tmax;

      let a = Array.make (tmax + 1) (Hashtbl.create 1) in
      
      for t = tmax downto 0 do
        Util.logdebug "t = %d" t;

        let (_, binmap) = conds.(t) in
        
        let ca = Hashtbl.create (Pmap.approx_size binmap) in
        a.(t) <- ca;
        
        Pmap.iter (fun (lows, obss) m ->  
          (*Util.logdebug "lows = %s" (Std.dump lows);
            Util.logdebug "obss = %s" (Std.dump obss);
            Util.logdebug "m =\n%s" (MM.to_string m);*)
            
          let attack_now = Util.maximize_float
            (List.map (fun exp ->
              (*Util.logdebug "considering exp = %s" (Std.dump exp);*)
              let temp = MM.expect
                (MM.bind m
                   (fun highs -> 
                     MM.bind (ME.to_map (gain_func t tmax highs lows obss exp)) MM.return))
                (fun x -> x) in
              (*Util.logdebug "prob of win = %f" temp;*)
                temp)
               !all_exps) in
          
          let attack_later = begin
            let best_later = ref neg_infinity in
              
            if t < tmax then begin
              List.iter (fun l ->
                (*Util.logdebug "considering low = %s" (Std.dump l);*)

                let na = a.(t+1) in

                (*Util.logdebug "na =\n%s" (Util.dump_hash na);*)

                let (Some next_cond, _) = conds.(t+1) in

                (*Util.logdebug "next_cond =\n%s" (Util.dump_parpmap next_cond);*)

                let goodness = 
                  try 
                    let temp_key = (P.epoch_low (t+1) (l :: lows),
                                    P.epoch_obs_prev (t+1) obss) in
                    (*Util.logdebug "looking up %s" (Std.dump temp_key);*)
                    let next_dist = Pmap.find temp_key next_cond in
                    (*Util.logdebug "next dist =\n%s" (MM.to_string next_dist);*)
                    MM.expect next_dist (fun o -> 
                      Hashtbl.find na (P.epoch_low (t+1) (l :: lows),
                                       P.epoch_obs (t+1) (o :: obss))
                    )

                  with | Not_found -> neg_infinity in
                
                if goodness > !best_later then best_later := goodness) !all_lows
            end;
              
            !best_later
          end in

          (*Util.logdebug "attack_now = %f, attack_later = %f" attack_now attack_later;
            Util.logdebug "";*)
          
          Hashtbl.replace ca (lows, obss) (max attack_now attack_later)
        ) binmap
      done;
      printf "%d\t%f\n%!" tmax (mf (Hashtbl.find a.(0) ([], [])))
    done      


end
;;
