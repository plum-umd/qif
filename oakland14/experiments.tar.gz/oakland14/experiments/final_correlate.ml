open ExtList
open ExtArray

module MM = Scenario.MM;;
module ME = Scenario.ME;;
module C = Common;;

let num_floors = ref 0;;
let num_builds = ref 2;;

let obs_odds = ref 1.00;;
let attack_change = ref false;;

module P = struct
  include Scenario.MAKE_FTYPES (struct
    type high = int * int
    type low = unit
    type obs = int
    type exp = high
  end)

  let all_highs = ref [];;
  let all_obss = ref [-1;0;1];;
  let all_lows = ref [()];;
  let all_exps = ref [];;
  let all_highfs = ref [||];;

  let epoch_low t ll = ll
  let epoch_obs t ll = ll
  let epoch_obs_prev t ll = ll
  let epoch_high t ll = ll

  let fix_params () =
    num_floors := Util.factorial (!num_builds - 1);

    all_highs := List.fold_left
      (fun a floor -> 
        a @ (List.fold_left
               (fun a build ->
                 (build, floor) :: a)
               []
               (Util.list_range 0 (!num_builds-1))))
      [] (Util.list_range 0 (!num_floors-1));

    all_exps := !all_highs;

    let perms =
      let ps = Util.gen_perms !num_builds in
      Array.of_list (List.map Array.of_list ps) in

    let make_pref_fun floor = begin
      let perm = perms.(floor) in
      let temp = Array.create !num_builds 0 in
      Array.iteri
        (fun i v -> temp.(v) <- perm.((i+1) mod !num_builds)) perm;
      
      fun t highs lows obss ->
        match highs with
          | [] -> ME.bind_uniform 0 (!num_builds - 1)
            (fun abuild -> 
              ME.return (abuild, floor))

          | (current_build, current_floor) :: _ ->
            (if not (current_floor = floor) then failwith "something bad");
            if (t mod !C.change_freq) = 0
            then ME.return (temp.(current_build), current_floor)
            else ME.return (current_build, current_floor)
    end in

    all_highfs :=
      Array.map make_pref_fun (Array.of_list (Util.list_range 0 (!num_floors-1)))
          
  let highgen_func () =
    ME.bind_uniform 0 (!num_floors - 1) ME.return

  let system t highs lows obss =
    match highs with
      | ((current_build, current_floor) :: _) ->
        ME.bind_flip !obs_odds (fun b ->
          if b then ME.return current_build else ME.return (-1))
      | _ -> failwith "absfun: unexpected"

  let strat_func t lows obss =
    if !C.adapt_low then 
      ME.bind_uniform_in !all_lows ME.return
    else
      ME.return ()

  let gain_func t tmax highs lows obss exp =
    if (not !C.adapt_wait) && (not (t = tmax)) then ME.return neg_infinity else
      match (highs, exp) with
        | ((current_build, current_floor) :: _,
           (exp_build, exp_floor)) -> 
          if !attack_change
          then ME.return (Util.float_of_bool (current_floor = exp_floor))
          else ME.return (Util.float_of_bool ((current_build, current_floor) = (exp_build, exp_floor)))
        | _ -> failwith "attackfun: unexpected"

end;;

module S = Scenario.SCENARIO (P);;

let () =
  C.parse [("--obs-odds",
            Arg.Set_float obs_odds, "odds of successful observation");
           ("--attack-change",
            Arg.Set attack_change, "graph vulnerability of change function");
           ("--nbuilds",
            Arg.Set_int num_builds, "number of buildings")];
  P.fix_params ();
  S.solve !C.tmax (fun x -> x)
  
