open ExtList
open Printf
open Option

type prob = float
let is_one p = (abs_float (1.0 -. p)) <= 0.00000001
let is_zero p = (abs_float p) <= 0.00000001

module MM = struct
  type 'a dist = ('a, prob) Pmap.t

  type ('a, 'b) bind = ('a -> 'b dist) -> 'b dist

  let scale p d = Pmap.map (fun p2 -> p *. p2) d;;

  let length d = Util.map_length d

  let of_list (choices: (prob * 'a) list): 'a dist =
    List.fold_left
      (fun a (p, v) -> Pmap.insert_with (+.) v p a)
      Pmap.empty choices
  ;;

  let bind d k =
    Pmap.foldi (fun v p a ->
      Util.maps_merge a (scale p (k v)) (+.))
      d Pmap.empty
  ;;

  let iter d f = Pmap.iter f d

  let bind_flip prob k =
    if is_one prob then bind (of_list [(1.0, true)]) k
    else if is_zero prob then bind (of_list [(1.0, false)]) k
    else
      bind (of_list [(prob, true);
                     (1.0 -. prob, false)]) k
  ;;

  let bind_flipint prob k =
    if is_one prob then bind (of_list [(1.0, 1)]) k
    else if is_zero prob then bind (of_list [(1.0, 0)]) k
    else
      bind (of_list [(prob, 1);
                     (1.0 -. prob, 0)]) k
  ;;

  let bind_uniform_in c k =
    let p = 1.0 /. (float_of_int (List.length c)) in
    bind (of_list (List.map (fun v -> (p, v)) c)) k
  ;;

  let bind_uniform = 
    fun a b k ->
      let p = 1.0 /. (float_of_int (b - a + 1)) in
      bind (of_list (List.map (fun v -> (p, v)) (Util.list_range a b))) k
  ;;

  let to_string d =
    String.concat "\n" (List.map (fun (p, v) -> sprintf "%f: %s" p (Std.dump v)) (Util.list_of_map d))

  let return v = Pmap.add v 1.0 (Pmap.empty);;

  let expect d f =
    Pmap.foldi
      (fun x p acc -> acc +. p *. (f x)) d 0.0

  let project_bins d fbinkey finsidebin = 
    let m = ref Pmap.empty in

    Pmap.iter (fun v p ->
      let k = fbinkey v in
      let bink = finsidebin v in

      m := Pmap.insert_with
        (fun a b -> match (a, b) with
          | ((prob_total1, `Single (bink1, p1)),
             (prob_total2, `Single (bink2, p2))) ->
            let m = Pmap.empty in
            let m = Pmap.add bink1 p1 m in
            (prob_total1 +. prob_total2, `Map (Pmap.insert_with (+.) bink2 p2 m))
          | ((prob_total1, `Map binm1), (prob_total2, `Single (bink2, p2)))
          | ((prob_total2, `Single (bink2, p2)), (prob_total1, `Map binm1)) ->
            (prob_total1 +. prob_total2,
             `Map (Pmap.insert_with (+.) bink2 p2 binm1))
          | _ -> failwith "shouldn't happen"
        )
        k
        (p, `Single (bink, p))
        !m)
      d;

    Pmap.mapi (fun k v -> match v with
      | (ptotal, `Single (k2, p)) -> (ptotal, Pmap.add k2 p (Pmap.empty))
      | (ptotal, `Map m) -> (ptotal, m)) !m

  let condition_and_project ~dist: adist ~what: whatfun ~on: onfun =
    let temp = project_bins adist onfun whatfun in
    Pmap.mapi (fun k (ptotal, m) -> scale (1.0 /. ptotal) m) temp

end;;

module ME = struct
  type 'a dist = ('a * prob) Enum.t

  type ('a, 'b) bind = ('a -> 'b dist) -> 'b dist

  let to_map d =
    Enum.fold
      (fun (v,p) a -> Pmap.insert_with (+.) v p a)
      Pmap.empty
      d

  let of_map d = Pmap.enum d

  let of_list (choices: ('a * prob) list) : 'a dist =
    List.enum choices

  let length d = 0

  let bind (enum1: 'a dist) (k: 'a -> 'b dist) : 'b dist =
    let maybe_e1 = ref None in
    let maybe_enum2 = ref None in

    let rec next = fun () ->
      match !maybe_e1 with
        | None ->
          maybe_e1 := Enum.get enum1;
          maybe_enum2 := None;
          begin match !maybe_e1 with
            | None -> raise Enum.No_more_elements
            | Some _ -> next () end
        | Some (v1, p1) ->
          match !maybe_enum2 with
            | None ->
              maybe_enum2 := Some (k v1);
              next ()
            | Some enum2 -> 
              match Enum.get enum2 with
                | None ->
                  maybe_e1 := None;
                  maybe_enum2 := None;
                  next ()
                | Some (v2, p2) -> (v2, p1 *. p2) in
    Enum.from next

  let bind_flip prob k =
    if is_one prob then bind (of_list [(true,1.0)]) k
    else if is_zero prob then bind (of_list [(false,1.0)]) k
    else
      bind (of_list [(true,prob);
                     (false,1.0 -. prob)]) k
  ;;

  let bind_flipint prob k =
    if is_one prob then bind (of_list [(1,1.0)]) k
    else if is_zero prob then bind (of_list [(0,1.0)]) k
    else
      bind (of_list [(1,prob);
                     (0,1.0 -. prob)]) k
  ;;

  let bind_uniform_in c k =
    let p = 1.0 /. (float_of_int (List.length c)) in
    bind (of_list (List.map (fun v -> (v, p)) c)) k
  ;;

  let bind_uniform : int -> int -> (int -> 'a dist) -> 'a dist = 
    fun a b k ->
      let p = 1.0 /. (float_of_int (b - a + 1)) in
      bind (of_list (List.map (fun v -> (v, p)) (Util.list_range a b))) k
  ;;

  let return v =
    let once = ref true in
    Enum.from (fun () -> if !once then begin once := false; (v, 1.0) end else raise Enum.No_more_elements)
end;;
