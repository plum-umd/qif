let nlocs = ref 4;;
let tmax = ref 12;;
let change_freq = ref 13;;
let adapt_low = ref false;;
let adapt_wait = ref false;;

let arg =
  [("--adapt-low",
    Arg.Set adapt_low, "low-adaptive");
   ("--adapt-wait",
    Arg.Set adapt_wait, "wait-adaptive");
   ("--change-freq",
    Arg.Set_int change_freq, "change frequency");
   ("--tmax",
    Arg.Set_int tmax, "tmax");
   ("--nlocs",
    Arg.Set_int nlocs, "number of locations")];;

let parse opts = 
  Arg.parse (arg @ opts)
    (fun s -> ()) "";;
