open ExtArray

module MM = Scenario.MM;;
module ME = Scenario.ME;;
module C = Common;;

let min_cf = ref 2;;
let max_cf = ref 4;;
let attack_change = ref false;;

module P = struct
  include Scenario.MAKE_FTYPES (struct
    type high = int * int
    type low = unit
    type obs = bool
    type exp = high
  end)

  let all_highs = ref [];;
  let all_obss = ref [true; false];;
  let all_lows = ref [()];;
  let all_exps = ref [];;
  let all_highfs = ref [||];;

  let epoch_low t ll = ll
  let epoch_obs t ll = ll
  let epoch_obs_prev t ll = ll
  let epoch_high t ll = ll

  let fix_params () =
    let all_cfs = [2;3;4] in
    all_highs := Util.lists_prod all_cfs (Util.list_range 0 (!C.nlocs-1));
    all_exps := !all_highs;
    
    let make_change_fun cf = begin
      fun t highs lows obss ->
        match highs with
          | [] -> ME.bind_uniform 0 (!C.nlocs - 1) (fun s -> ME.return (cf, s))
          | (cf, current_high) :: _ ->
            if (t mod cf) = 0
            then ME.bind_uniform 0 (!C.nlocs - 1) (fun s -> ME.return (cf, s))
            else ME.return (cf, current_high)
    end in

    all_highfs :=
      Array.map make_change_fun (Array.of_list all_cfs)
          
  let highgen_func () =
    ME.bind_uniform 0 ((Array.length !all_highfs) - 1) ME.return

  let system t highs lows obss =
    match highs with
      | (cf, current_high) :: _ ->
        ME.return (current_high = (t mod !C.nlocs))
      | _ -> failwith "obsfun: unexpected"

  let strat_func t lows obss =
    if !C.adapt_low then 
      ME.bind_uniform_in !all_lows ME.return
    else
      ME.return ()

  let gain_func t tmax highs lows obss exp =
    if (not !C.adapt_wait) && (not (t = tmax)) then ME.return neg_infinity else
      match (highs, exp) with
        | ((current_cf, current_high) :: _, (exp_cf, exp_high)) ->
          if !attack_change
          then ME.return (Util.float_of_bool (current_cf = exp_cf))
          else ME.return (Util.float_of_bool (current_high = exp_high))
        | _ -> failwith "attackfun: unexpected"

end;;

module S = Scenario.SCENARIO (P);;

let () =
  C.parse [
    ("--min-cf",
     Arg.Set_int min_cf, "change frequency minimum");
    ("--max-cf",
     Arg.Set_int max_cf, "change frequency maximum");
    ("--attack-change",
     Arg.Set attack_change, "output change vulnerability")];
  P.fix_params ();
  S.solve !C.tmax (fun x -> x)
