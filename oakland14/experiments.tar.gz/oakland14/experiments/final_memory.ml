module MM = Scenario.MM;;
module ME = Scenario.ME;;
module C = Common;;

let mem_limit = ref 1000;;

module P = struct
  include Scenario.MAKE_FTYPES (struct
    type high = int
    type low = int
    type obs = bool
    type exp = int
  end)

  let all_highs = ref [];;
  let all_obss = ref ([true; false]);;
  let all_lows = ref [];;
  let all_exps = ref [];;

  let epoch_low t ll = ll
  let epoch_obs t ll = ll
  let epoch_obs_prev t ll = ll
  let epoch_high t ll = ll

  let fix_params () =
    all_highs := Util.list_range 0 (!C.nlocs-1);
    all_exps := !all_highs;
    all_lows := !all_highs
        
  let all_highfs = ref [|
    fun t highs lows obss ->
      match highs with
        | [] ->
          ME.bind_uniform_in !all_highs ME.return
        | current_high :: rest_highs ->
          if (t mod !C.change_freq) = 0
          then ME.bind_uniform_in !all_highs ME.return
          else ME.return current_high
                        |]
          
  let highgen_func () =
    ME.return 0

  let system t highs lows obss =
    match (highs, lows) with
      | (current_high :: _, current_low :: _) ->
        ME.return (current_high = current_low)
      | _ -> failwith "absfun: unexpected"
  
  let strat_func t lows obss =
    if !C.adapt_low then 
      ME.bind_uniform_in !all_lows ME.return
    else
      ME.return (t mod !C.nlocs)

  let gain_func t tmax highs lows obss exp =
    if (not !C.adapt_wait) && (not (t = tmax)) then ME.return neg_infinity else
      match highs with
        | current_high :: _ -> 
          ME.return (Util.float_of_bool (exp = current_high))
        | _ -> failwith "attackfun: unexpected"
end

module S = Scenario.SCENARIO (P);;

let () =
  C.parse [("--mem-limit",
            Arg.Set_int mem_limit, "asdf")];
  P.fix_params ();
  S.solve_mem_limit !C.tmax !mem_limit (fun x -> x)
