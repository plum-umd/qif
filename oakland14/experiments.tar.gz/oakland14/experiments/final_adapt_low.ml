open ExtList
open ExtArray

module MM = Scenario.MM;;
module ME = Scenario.ME;;
module C = Common;;

let strat = ref 0;;

module P = struct
  include Scenario.MAKE_FTYPES (struct
    type high = int
    type low = int
    type obs = int
    type exp = int
  end)

  let all_highs = ref [];;
  let all_obss = ref [];;
  let all_lows = ref [];;
  let all_exps = ref [];;

  let epoch_low t ll = ll
  let epoch_obs t ll = ll
  let epoch_obs_prev t ll = ll
  let epoch_high t ll = ll

  let all_strats = ref [||];;

  let fix_params () =
    all_highs := Util.list_range 0 (!C.nlocs-1);
    all_exps := !all_highs;
    all_lows    := !all_highs;
    all_obss    := [0;1];
    
    all_strats :=
      Array.of_list
      (List.map Array.of_list
         ((Util.gen_inserts_of
             (Util.list_range 0 (!C.nlocs-2)) (!C.nlocs - 1))));;

  let all_highfs =
    ref [|
      fun t highs lows obss ->
        match highs with
          | [] ->
            ME.bind_uniform_in !all_highs ME.return
          | current_high :: rest_highs ->
            ME.return current_high
        |]
          
  let highgen_func () =
    ME.return 0

  let system t highs lows obss =
    match (highs, lows) with
      | (current_high :: _, current_low :: _) ->
        if current_high <= current_low then ME.return 1 else ME.return 0
      | _ -> failwith "obsfun: unexpected"
        
  let strat_func t lows obss =
    if !C.adapt_low then 
      ME.bind_uniform_in !all_lows ME.return
    else
      ME.return (!all_strats).(!strat).(t mod !C.nlocs)

  let gain_func t tmax highs lows obss exp =
    if (not !C.adapt_wait) && (not (t = tmax)) then ME.return neg_infinity else
      match highs with
        | current_high :: _ -> 
          ME.return (Util.float_of_bool (exp = current_high))
        | _ -> failwith "attackfun: unexpected"
end

module S = Scenario.SCENARIO (P);;

let () =
  C.parse [("--strat", Arg.Set_int strat, "strategy index")];
  P.fix_params ();
  S.solve !C.tmax (fun x -> x)

