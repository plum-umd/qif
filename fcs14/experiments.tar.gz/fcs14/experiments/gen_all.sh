sh gen_penalty.sh
sh gen_keyrand.sh
sh gen_sound.sh
