open Printf
open Pmonad

let () =
  let c1orc2 =
    ME.bind_flip 0.5 (fun c1 ->
      ME.bind_flip 0.5 (fun c2 ->
        ME.return (c1 || c2))) in
  let c1orc2 = ME.to_map c1orc2 in
  let ptrue = MM.prob_of c1orc2 true in
  let pfalse = MM.prob_of c1orc2 false in
  printf "true = %f\n%!" ptrue;
  printf "false = %f\n%!" pfalse;
  printf "dist = \n%s\n%!" (MM.to_string c1orc2)
