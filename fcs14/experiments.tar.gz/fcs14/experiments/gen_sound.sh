DIR="../data/data_sound"
COMMON_FLAGS="--nlocs 8 --tmax 12 --change-freq 4 --obs-penalty 0.00 --adapt-low --adapt-wait"

mkdir -p ${DIR}

(./exp_sound ${COMMON_FLAGS} > ${DIR}/data.tsv; echo "done") &
(./exp_sound ${COMMON_FLAGS} --gain-overestimate > ${DIR}/data_overestimate.tsv; echo "overestimate done") &

wait
echo "ALL DONE"
