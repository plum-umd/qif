let nlocs = ref 8;;
let tmax = ref 4;;
let change_freq = ref 13;;
let adapt_low = ref false;;
let adapt_wait = ref false;;
let zerosum = ref false;;

let arg =
  [("--debug",
    Arg.Set Util.debug, "debug mode");
   ("--adapt-low",
    Arg.Set adapt_low, "low-adaptive");
   ("--adapt-wait",
    Arg.Set adapt_wait, "wait-adaptive");
   ("--change-freq",
    Arg.Set_int change_freq, "change frequency");
   ("--tmax",
    Arg.Set_int tmax, "tmax");
   ("--nlocs",
    Arg.Set_int nlocs, "number of locations");
   ("--zero-sum",
    Arg.Set zerosum, "use zero-sum util/gain")];;

let parse opts ep = 
  Arg.parse (arg @ opts)
    (fun s -> ()) "";
  Util.logerr "%s --nlocs %d --tmax %d --change-freq %d %s%s%s%s"
    Sys.executable_name
    !nlocs
    !tmax
    !change_freq
    (if !adapt_low then "--adapt-low " else "")
    (if !adapt_wait then "--adapt-wait " else "")
    (if !zerosum then "--zero-sum " else "")
    (ep ())
;;


