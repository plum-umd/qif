open Printf
open ExtList
open ExtArray
open ExtHashtbl

let () = Printexc.record_backtrace true;;

module MM = Pmonad.MM;;
module ME = Pmonad.MM;;

module type BASE_TYPES = sig
  type dact
  type high
  type obs
  type low
  type exp
end;;

module type PARAMS = sig
  include BASE_TYPES

  type act =
    | Low of low
    | Exp of exp

  type highgenf = int -> int ->
      high list -> act list -> obs list -> dact -> high ME.dist

  type dactstratf = int -> int ->
      high list -> act list -> obs list -> dact ME.dist
  type dactstratspanf = int -> int ->
      high list -> act list -> obs list -> dact list
  type dactstratpriorf = unit -> int ME.dist

  type actstratf = int -> int ->
      act list -> obs list -> act ME.dist
  type actstratspanf = int -> int ->
      act list -> obs list -> act list

  type sysf = int -> int ->
      high list -> act list -> obs list -> obs ME.dist
  type gainf = int -> int ->
      high list -> act list -> obs list -> float ME.dist
  type lossf = int -> int ->
      high list -> act list -> obs list -> float ME.dist

  val all_dacts: dact list ref
  val all_highs: high list ref
  val all_lows: low list ref
  val all_obss: obs list ref
  val all_exps: exp list ref
  val all_dactstratfs: (dactstratf array) ref

  val highgen_func: highgenf
  val dactstrat_prior_func: dactstratpriorf
  val dactstrat_span_func: dactstratspanf
  val actionstrat_span_func: actstratspanf
  val system_func: sysf
  val gain_func: gainf
  val loss_func: lossf
end;;

module MAKE_FTYPES (BT: BASE_TYPES) = struct
  include BT

  type act =
    | Low of BT.low
    | Exp of BT.exp

  type highgenf = int -> int ->
      BT.high list -> act list -> BT.obs list -> BT.dact -> BT.high ME.dist
      
  type dactstratf = int -> int ->
      BT.high list -> act list -> BT.obs list -> BT.dact ME.dist
  type dactstratspanf = int -> int ->
      BT.high list -> act list -> BT.obs list -> BT.dact list
  type dactstratpriorf = unit -> int ME.dist

  type actstratf = int -> int ->
      act list -> BT.obs list -> act ME.dist
  type actstratspanf = int -> int ->
      act list -> BT.obs list -> act list

  type sysf = int -> int ->
      BT.high list -> act list -> BT.obs list -> BT.obs ME.dist
  type gainf = int -> int ->
      BT.high list -> act list -> BT.obs list -> float ME.dist
  type lossf = int -> int ->
      BT.high list -> act list -> BT.obs list -> float ME.dist
end;;

module SCENARIO (P: PARAMS) = struct
  include P

  type history = {highs: high list;
                  acts: act list;
                  obss: obs list}

  type state = {hist: history;
                dactstrat: int}

  let construct_actstrat_opt tmax =
    (* Util.logerr "joint dist made (size %d)" (ME.length d);*)
    (* let (dist: history MM.dist) = ME.to_map d in*)

    let opthash = Hashtbl.create 16 in

    let state_dist = ME.bind (P.dactstrat_prior_func ())
      (fun dact_strat -> 
        ME.bind ((!P.all_dactstratfs).(dact_strat) 0 tmax [] [] [])
          (fun dact ->
            ME.bind (P.highgen_func 0 tmax [] [] [] dact)
              (fun h ->
                let history = {highs= [h]; acts= []; obss= []} in
                ME.return {hist= history;
                           dactstrat= dact_strat}))) in

    let rec continue current_state_dist t acts obss =
      (*Util.logdebug "%scontinuing from %d [%s,%s]" tab
        t
        (Std.dump acts)
        (Std.dump obss);*)
      
      let next_acts = P.actionstrat_span_func t tmax acts obss in
      let best_gain = ref neg_infinity in
      let best_act = ref None in
      let resulting_loss = ref neg_infinity in
      
      let end_eval next_act = begin
        let gdist = ME.bind current_state_dist (fun s ->
          ME.bind
            (P.gain_func t tmax
               s.hist.highs
               (next_act :: s.hist.acts)
               s.hist.obss
            ) ME.return) in

        let expect_gain = MM.expect (ME.to_map gdist) in
        (*Util.logdebug "%sfinal gain for action %s is %f"
          tab (Std.dump next_act) expect_gain;*)
        if expect_gain > !best_gain then
          begin
            (*Util.logdebug "%snew best is final" tab;*)
            best_gain := expect_gain;
            best_act := Some next_act;
            
            let ldist = ME.bind current_state_dist (fun s ->
              ME.bind
                (P.loss_func t tmax
                   s.hist.highs
                   (next_act :: s.hist.acts)
                   s.hist.obss
                ) ME.return) in
            resulting_loss := MM.expect (ME.to_map ldist)
          end
      end in

      List.iter (fun next_act ->
        match next_act with
          | Low l when t < tmax ->
            let next_state_dist =
              ME.bind current_state_dist
                (fun s ->
                  ME.bind (P.system_func t tmax
                             (s.hist.highs)
                             (next_act :: s.hist.acts)
                             s.hist.obss)
                    (fun next_obs ->
                      ME.bind ((!P.all_dactstratfs).(s.dactstrat)
                                  (t+1) tmax
                                  s.hist.highs
                                  (next_act :: s.hist.acts)                         
                                  (next_obs :: s.hist.obss))
                        (fun next_dact -> 
                          ME.bind (P.highgen_func
                                     (t+1) tmax
                                     s.hist.highs
                                     (next_act :: s.hist.acts)                         
                                     (next_obs :: s.hist.obss)
                                     next_dact)
                            (fun next_high ->
                              ME.return
                                {s with hist = {highs = (next_high :: s.hist.highs);
                                                acts = (next_act :: s.hist.acts);
                                                obss = (next_obs :: s.hist.obss)}})))) in

            let temp = ME.to_map next_state_dist in
            let conds = MM.project_bins temp
              (fun s -> (s.hist.acts, s.hist.obss))
              (fun s -> s) in
            
            let temp_gain = ref 0.0 in
            let temp_loss = ref 0.0 in

            Pmap.iter (fun (next_acts, next_obss) (ptotal, next_state_dist) ->
              let (next_gain, next_loss) =
                continue
                  (ME.of_map (MM.normalize next_state_dist))
                  (t+1)
                  next_acts
                  next_obss in
              temp_gain := !temp_gain +. (ptotal *. next_gain);
              temp_loss := !temp_loss +. (ptotal *. next_loss)) conds;

            let expect_gain = !temp_gain in
            (*Util.logdebug "%snon-final gain for action %s is %f"
              tab (Std.dump next_act) expect_gain;*)

            if ((expect_gain = !best_gain) && (!temp_loss > !resulting_loss))
              || (expect_gain > !best_gain) then
              begin
                (*Util.logdebug "%snew best is NOT final" tab;*)
                best_gain := expect_gain;
                best_act := Some next_act;
                resulting_loss := !temp_loss
              end
          | _ -> end_eval next_act
      ) next_acts;
      (*Util.logdebug "%sG[%s,%s] = %f" tab
        (Std.dump acts)
        (Std.dump obss)
        (!best_gain);*)
      (*Util.logdebug "%sA[%s,%s] = %s"
        tab (Std.dump acts) (Std.dump obss) (Std.dump !best_act);*)
      Hashtbl.replace opthash (t, tmax, acts, obss) (Option.get !best_act);
      (!best_gain, !resulting_loss)
    in

    let (gain_expect, loss_expect) = continue state_dist 0 [] [] in
    let actstrat_opt = fun t tmax acts obss ->
      (Hashtbl.find opthash (t, tmax, acts, obss)) in
    (gain_expect, loss_expect, actstrat_opt)

  let construct_highstrat_worst_best actstrat_opt tmax =
    (*let worsthighstrat = Hashtbl.create 16 in*)
    
    let rec continue dactspanfunc t highs acts obss = begin
      let next_dacts = dactspanfunc t tmax highs acts obss in
      
      let worst_loss = ref neg_infinity in
      let worst_dact = ref None in
      let best_loss = ref infinity in
      let best_dact = ref None in

      let next_act = actstrat_opt t tmax acts obss in

      List.iter (fun next_dact ->
        let next_state_dist =
          ME.bind (P.highgen_func t tmax
                     highs (next_act :: acts) obss next_dact)
            (fun next_high -> ME.return (next_high :: highs, next_act :: acts, obss)) in
        
        begin match next_act with
          | Low l when t < tmax -> (
            let next_state_dist = ME.bind next_state_dist
              (fun (highs, acts, obss) ->
                ME.bind (P.system_func t tmax
                           highs acts obss)
                  (fun next_obs ->
                    ME.return (highs, acts, next_obs :: obss))) in

            let loss_dist = ME.bind next_state_dist
              (fun (highs, acts, obss) -> ME.return (continue dactspanfunc (t+1) highs acts obss)) in

            let loss_dist = ME.to_map loss_dist in
            let worst_later = MM.expect_map loss_dist fst in
            if worst_later > !worst_loss then begin
              worst_loss := worst_later;
              worst_dact := Some next_act
            end;
            let best_later = MM.expect_map loss_dist snd in
            if best_later < !best_loss then begin
              best_loss := best_later;
              best_dact := Some next_act
            end)
          | _ -> (
            let loss_dist = ME.bind next_state_dist
              (fun (highs, acts, obss) -> 
                ME.bind (P.loss_func t tmax highs acts obss) ME.return) in
            let loss_dist = ME.to_map loss_dist in
            let loss_now = ME.expect loss_dist in
            if loss_now > !worst_loss then begin
              worst_loss := loss_now;
              worst_dact := Some next_act
            end;
            if loss_now < !best_loss then begin
              best_loss := loss_now;
              best_dact := Some next_act
            end)
        end) next_dacts;
      (!worst_loss, !best_loss)
    end in
    (*let ult_loss = ref infinity in*)

    continue P.dactstrat_span_func 0 [] [] []

  let simulate tmax =
    Util.logerr "simulating for tmax up to %d" tmax;
    for t = 0 to tmax do
      let (gain_expect, loss_expect, actstrat_opt) = construct_actstrat_opt t in
      let (loss_worst, loss_best) = construct_highstrat_worst_best actstrat_opt t in
      printf "%d\t%f\t%f\t%f\t%f\n%!" t gain_expect loss_expect loss_worst loss_best;
      Util.logerr "%d\t%f\t%f\t%f\t%f" t gain_expect loss_expect loss_worst loss_best
        
    (*let (eg, er, wcr, bcr) = solve_for t in
      printf "%d\t%f\t%f\t%f\t%f\n%!" t eg er wcr bcr*)
    done

end
;;

