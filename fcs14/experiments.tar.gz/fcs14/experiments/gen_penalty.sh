mkdir -p ../data/data_penalty

for P in 0.00 0.05 0.10 0.15
do
    (./exp_penalty --nlocs 8 --tmax 12 --change-freq 4 --obs-penalty ${P} --adapt-low --adapt-wait > ../data/data_penalty/${P}_wait.tsv; echo "${P} wait done") &
    (./exp_penalty --nlocs 8 --tmax 12 --change-freq 4 --obs-penalty ${P} --adapt-low --adapt-wait --zero-sum > ../data/data_penalty/${P}_wait_zerosum.tsv; echo "${P} wait zero-sum done") &
done

wait
echo "ALL DONE"
