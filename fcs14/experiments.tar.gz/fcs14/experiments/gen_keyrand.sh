mkdir -p ../data/data_keyrand

(./exp_keyrand --nlocs 8 --tmax 12 --change-freq 4 --def-change-freq 4 --adapt-low --adapt-wait --obs-penalty 0.05 > ../data/data_keyrand/move4.tsv; echo "done") &
(./exp_keyrand --nlocs 8 --tmax 12 --change-freq 4 --def-change-freq 4 --adapt-low --adapt-wait --obs-penalty 0.05 --decide > ../data/data_keyrand/move4_decide.tsv; echo "done") &
(./exp_keyrand --nlocs 8 --tmax 12 --change-freq 4 --def-change-freq 4 --adapt-low --adapt-wait --obs-penalty 0.05 --decide --decide-initial > ../data/data_keyrand/move4_decide_initial.tsv; echo "done") &

wait
echo "ALL DONE"
